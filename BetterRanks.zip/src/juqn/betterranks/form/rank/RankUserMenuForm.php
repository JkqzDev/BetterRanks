<?php

declare(strict_types=1);

namespace juqn\betterranks\form\rank;

use cosmicpe\form\entries\simple\Button;
use cosmicpe\form\SimpleForm;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

final class RankUserMenuForm extends SimpleForm {

    public function __construct(string $xuid, ?string $name = null) {
        parent::__construct('User Rank Menu');
        $buttons = [
            '&7Set Rank' => new RankSetUserForm($xuid, $name),
            '&7Remove Rank' => new RankRemoveUserForm($xuid, $name),
            '&cBack' => new RankManageUserForm(),
        ];

        foreach ($buttons as $title => $form) {
            $this->addButton(
                new Button(TextFormat::colorize($title)),
                fn(Player $player, int $button_index) => $player->sendForm($form)
            );
        }
    }
}